********************************************************************************************************************************************************
# Automation Framework - Baseline
1. UI Framework
    - Run UI test with multiple browsers
    - Serenity Report
2. API (RestAssured)
    - Allure Report
3. Gatling
4. Opencv
   - Steps for Opencv execution
5. Miscellaneous
   - Steps to test with headless mode
   - SeleniumBoxIntegration Setup

-------------------------------------------------------------------------------------------------------------------------------------------------------
## 1.UI Framework 
- Run the command `mvn clean verify -D"cucumber.filter.tags=@UI` to run all the features and scenarios with `@UI` tag
- Run the command `mvn clean verify -Dtest=UITestRunner` to run the UI test runner

  ## Run UI test with multiple browsers
  
  The ShopBack Automation framework supports Chrome, Firefox and Edge.
  
  - Run the command `mvn clean verify -P ui.chrome` to execute tests with Chrome
    - Run the command `mvn clean verify -P ui.firefox` to execute tests with Firefox
    - Run the command `mvn clean verify -P ui.edge` to execute tests with Edge
    - Run the command `mvn clean verify -P ui.chrome,ui.firefox,ui.edge` to execute tests with all supported browsers
  
  If no profile specified, default profile will get executed with chrome.
  
  Specify browser versions:
  Using `chrome.version`, `firefox.version`, `edge.version` system properties to run test with specific browser versions.
  Example, `mvn clean verify -P ui.chrome,ui.edge,ui.firefox -Dchrome.version=121 -Dfirefox.version=120`. This command
  will run tests with Chrome v.121, Firefox v.120 and Edge (default version).

  ## Serenity Report
  - refer to https://github.com/serenity-bdd/serenity-documentation/blob/master/src/asciidoc/screenshots.adoc#basic-screenshot-configuration
    - After run the test with mvn cmd, the serenity report can be found at `/run-results/serenity`
    - To change the screenshot option, go to `serenity.properties` and change the option `serenity.take.screenshots` to following one of below value:
      - AFTER_EACH_STEP
      - FOR_FAILURES
      - FOR_EACH_ACTION
-------------------------------------------------------------------------------------------------------------------------------------------------------

## 2.API (RestAssured)
Executing API tests via the api profile.
See the command below:

- `mvn clean verify -P api` to execute tests.
  Notes:
* Specify api profile :`-P api`

  ## Allure Report
   - To execute API profile for testing RestAssured clasess use `mvn clean verify -P api`
     -  To execute the allure reports then try following command `allure serve target/allure-results --debug`

-------------------------------------------------------------------------------------------------------------------------------------------------------

## 3.Gatling
- To execute Gatling profile for testing simulation classes and generating reports use `mvn clean verify -P gatling`

-------------------------------------------------------------------------------------------------------------------------------------------------------

## 4.Opencv

  ## Steps for Opencv execution
- To execute Opencv feature classes specify `features = "src/test/resources/features/VisualTesting_Opencv.feature"` 
  inside CucumberOptions property defined in UITestRunner before execution.

-------------------------------------------------------------------------------------------------------------------------------------------------------

## 5.Miscellaneous
- Run the command `mvn clean verify` to run all the features and scenarios
 
  ## Steps to test with headless mode
    - Opening file: `serenity.properties`
    - Change the value of `headless.mode` to `true`
    - Rebuild project and run the test

  ## SeleniumBoxIntegration Setup
    - Raise a new request in JIRA for the required access to selenium-grid and set it up accordingly.

********************************************************************************************************************************************************