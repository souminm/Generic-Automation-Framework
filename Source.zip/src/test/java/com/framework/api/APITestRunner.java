package com.framework.api;

import com.framework.api.tests.OfferSearchTest;
import com.framework.api.tests.OffersEligibilityTest;
import com.framework.api.tests.healthTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({healthTest.class,OfferSearchTest.class, OffersEligibilityTest.class})
public class APITestRunner {
}
