package com.framework.api.tests;


import com.framework.common.utilities.APIConfig;
import com.framework.common.utilities.APIUtils;
import com.framework.common.utilities.RestAssuredBase;
import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;

public class OffersEligibilityTest {
    private static final Logger log = LoggerFactory.getLogger(OffersEligibilityTest.class);
    static String key = null;
    static String secret = null;
    static String path = null;
    static String uri = null;
    static JSONArray payloadArray = null;
    static String firstPayloadItem = null;
    static JSONArray pathVariableArray = null;
    static String customerId = null;
    static String INVALID_CUSTOMER_ID= "12345678";

    static {
        try {
            APIConfig offerEligibilityConfig = APIUtils.getOfferEligibility();
            payloadArray = offerEligibilityConfig.getPayload();
            firstPayloadItem = payloadArray.getJSONObject(0).toString();
            pathVariableArray = offerEligibilityConfig.getPathVariable();
            customerId = pathVariableArray.getJSONObject(0).optString("customerId");
            key = offerEligibilityConfig.getKey();
            secret = offerEligibilityConfig.getSecret();
            uri = offerEligibilityConfig.getUri();
            path = offerEligibilityConfig.getPath();
        } catch (IOException | JSONException e) {
            log.error(e.getMessage());
        }
    }

    @Test
    /*
     GIVEN: Offer Eligibility request is set up correctly,
     WHEN: User send POST request '/offersEligibility',
     THEN: They should obtain offer with different information
     */
    public void postOfferEligibilitySuccessfully() throws IOException {
        given()
                .spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/customers/" + customerId + "/offersEligibility")
                .queryParam("brandSilo", "WPAC")
                .queryParam("customerIdScheme", "CustomerInternalId")
                .body(firstPayloadItem)
                .when()
                .post()
                .then()
                .statusCode(200)
                .body("data.offerStatus[0].programType", equalTo("SHOPBACK"))
                .body("data.offerStatus[0].isEligible", equalTo(true))
                .body("data.offerStatus[1].programType", equalTo("WESTPAC_OFFERS_AND_REWARDS"))
                .body("data.offerStatus[1].isEligible", equalTo(false))
                .body("data.offerStatus[1].ineligibilityReason", equalTo("CUSTOMER_ENTITLEMENT_CHECK_FAILED"));
    }

    @Test
    /* Negative Test Case:
    GIVEN: Query Param "customerIdScheme" is absent,
    WHEN: User send POST request,
    THEN: User should get detail message as "The required customerIdScheme in Query parameter is missing or invalid"
     */
    public void postOfferEligibilityMissingCustomerIdSchemeParam() {
        List<?> responseList = given()
                .spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/customers/" + customerId + "/offersEligibility")
                .queryParam("brandSilo", "WPAC")
                .body(firstPayloadItem)
                .when()
                .post()
                .then()
                .statusCode(400)
                .extract()
                .path("result.errors.details");
        assertEquals(responseList.get(0), "The required customerIdScheme in query parameter is missing or invalid");
    }

    @Test
    /*Negative Test Case:
    GIVEN: Query Param "brandSilo" is absent,
    WHEN: User send POST request,
    THEN: User should get detail message as "The required brandSilo in Query parameter is missing or invalid"
     */
    public void postOfferEligibilityMissingBrandSiloParam() {
        List<?> responseList = given()
                .spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/customers/" + customerId + "/offersEligibility")
                .queryParam("customerIdScheme", "CustomerInternalId")
                .body(firstPayloadItem)
                .when()
                .post()
                .then()
                .statusCode(400)
                .extract()
                .path("result.errors.details");
        assertEquals(responseList.get(0), "The required brandSilo in query parameter is missing or invalid");
    }

     @Test
    /* Negative Test Case:
    GIVEN: Path Param "customerId" is invalid,
    WHEN: User send POST request,
    THEN: User should get detail message as "The required customerId in path parameter is missing or invalid" as the error reflects in downstream about path variable i.e invalid"
     */
    public void postOfferEligibilityHavingInvalidCustomerIdPathParam() {
         List<?> responseList = given()
                 .spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/customers/" + INVALID_CUSTOMER_ID + "/offersEligibility")
                 .queryParam("brandSilo", "WPAC")
                 .queryParam("customerIdScheme", "CustomerInternalId")
                 .body(firstPayloadItem)
                 .when()
                 .post()
                 .then()
                 .statusCode(400)
                 .extract()
                 .path("result.errors.details");
         assertEquals(responseList.get(0), "The required customerId in path parameter is missing or invalid");
    }
}
