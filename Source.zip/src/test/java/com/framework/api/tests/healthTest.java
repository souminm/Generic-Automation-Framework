package com.framework.api.tests;


import com.framework.common.utilities.APIConfig;
import com.framework.common.utilities.APIUtils;
import com.framework.common.utilities.RestAssuredBase;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class healthTest {

    private static final Logger log = LoggerFactory.getLogger(healthTest.class);
    static String key = null;
    static String secret = null;
    static String path = null;
    static String uri = null;

    static {
        try {
            APIConfig healthConfig = APIUtils.getHealthStatus();
            key = healthConfig.getKey();
            secret = healthConfig.getSecret();
            uri = healthConfig.getUri();
            path = healthConfig.getPath();
        } catch (IOException e) {
            log.error(e.getMessage());
        }
    }

    @Test
    /*
     GIVEN: Offer Search request is set up correctly,
     WHEN: User send health GET request '/healthcheck',
     THEN: They should obtain status with health information
     */
    public void testConsumerInfHealthGetRequest() {
        given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).when()
                .get(path)
                .then()
                .statusCode(200)
                .body("status", equalTo("success"));
    }
}
