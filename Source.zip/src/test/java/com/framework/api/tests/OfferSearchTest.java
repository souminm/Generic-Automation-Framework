package com.framework.api.tests;

import com.framework.common.utilities.APIConfig;
import com.framework.common.utilities.APIUtils;
import com.framework.common.utilities.RestAssuredBase;
import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;

public class OfferSearchTest {
    static String key = null;
    static String secret = null;
    static String path = null;
    static String uri = null;
    static JSONArray payloadArray = null;
    static JSONArray pathVariableArray = null;
    static String firstPayloadItem = null;
    static String offerId = null;
    static String INVALID_OFFER_ID = "12345";
    private static final Logger log = LoggerFactory.getLogger(OfferSearchTest.class);

    static {
        try {
            APIConfig offerSearchConfig = APIUtils.getOfferSearch();
            payloadArray = offerSearchConfig.getPayload();
            firstPayloadItem = payloadArray.getJSONObject(0).toString();
            pathVariableArray = offerSearchConfig.getPathVariable();
            offerId = pathVariableArray.getJSONObject(0).optString("offerId");
            key = offerSearchConfig.getKey();
            secret = offerSearchConfig.getSecret();
            uri = offerSearchConfig.getUri();
            path = offerSearchConfig.getPath();
        } catch (IOException | JSONException e) {
            log.error(e.getMessage());
        }
    }

    @Test
    /*
     GIVEN: Offer Search request is set up correctly,
     WHEN: User send POST request '/offerSearch',
     THEN: They should obtain offer with different information
     */
    public void postOfferSearchSuccessfully() throws IOException {
        given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offerSearch")
                .queryParam("brandSilo", "WPAC").queryParam("programType", "SHOPBACK")
                .body(firstPayloadItem).when().post().then().statusCode(200)
                .body("offers[0].name", equalTo("Amazon Australia"));
    }

    @Test
    /* Negative Test Case:
    GIVEN: Query Param "programType" is absent,
    WHEN: User send POST request,
    THEN: User should get detail message as "The required programType in Query parameter is missing or invalid"
     */
    public void postOfferSearchMissingProgramTypeParam() {
        List<?> responseList = given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offerSearch").queryParam("brandSilo", "WPAC").body(firstPayloadItem).when().post().then().statusCode(400).extract().path("result.errors.details");
        assertEquals(responseList.get(0), "The required programType in Query parameter is missing or invalid");
    }

    @Test
    /*Negative Test Case:
    GIVEN: Query Param "brandSilo" is absent,
    WHEN: User send POST request,
    THEN: User should get detail message as "The required brandSilo in Query parameter is missing or invalid"
     */
    public void postOfferSearchMissingBrandSiloParam() {
        List<?> responseList = given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offerSearch").queryParam("programType", "SHOPBACK").body(firstPayloadItem).when().post().then().statusCode(400).extract().path("result.errors.details");
        assertEquals(responseList.get(0), "The required brandSilo in Query parameter is missing or invalid");
    }

    @Test
    /*
    GIVEN: Offer Search request is set up correctly,
    WHEN: User send POST request with queryParam as nextPageKey,
    THEN: They should obtain offer with different information
     */
    public void postOfferSearchWithNextPageKeyParam() {
        given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offerSearch").queryParam("brandSilo", "WPAC").queryParam("programType", "SHOPBACK").queryParam("nextPageKey", 10).body(firstPayloadItem).when().post().then().statusCode(200).body("offers[0].offerId", equalTo("12345")).body("offers[0].name", equalTo("Amazon Australia")).body("offers[0].cashback.displayText", equalTo("Up to 10% Cashback")).body("offers[0].subCategory.name", equalTo("FitnessMock")).body("offers[0].bonusCashback.displayText", equalTo("2% bonus Cashback - Vicky"));
    }

    @Test
    /*
    GIVEN: Offer Search request is set up correctly,
    WHEN: User send GET request '/offers/:offerId',
    THEN: They should obtain offer with different information
     */
    public void getOffersSearchSuccessfully() {
        given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offers/" + offerId).queryParam("brandSilo", "WPAC").queryParam("programType", "SHOPBACK").when().get().then().statusCode(200)
              .body("name", equalTo("Amazon Australia"));
    }

    @Test
    /* Negative Test Case:
    GIVEN: Query Param "brandSilo" is absent,
    WHEN: User send GET request,
    THEN: User should get detail message as "The required brandSilo in Query parameter is missing or invalid"
     */
    public void getOffersSearchMissingBrandSiloParam() {
        List<?> responseList = given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offers/" + offerId).queryParam("programType", "SHOPBACK").when().get().then().statusCode(400).extract().path("result.errors.details");
        assertEquals(responseList.get(0), "The required brandSilo in Query parameter is missing or invalid");
    }

    @Test
    /* Negative Test Case:
    GIVEN: Query Param "programType" is absent,
    WHEN: User send GET request,
    THEN: User should get detail message as "The required programType in Query parameter is missing or invalid"
     */
    public void getOffersSearchMissingProgramTypeParam() {
        List<?> responseList = given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offers/" + offerId).queryParam("brandSilo", "WPAC").when().get().then().statusCode(400).extract().path("result.errors.details");
        assertEquals(responseList.get(0), "The required programType in Query parameter is missing or invalid");
    }

     @Test
    /* Negative Test Case:
    GIVEN: Path Param "offerId" is invalid,
    WHEN: User send GET request,
    THEN: User should get detail message as "An unexpected error while processing as the error reflects in downstream about path variable i.e invalid"
     */
    public void getOffersSearchHavingInvalidOfferIdPathParam() {
        List<?> responseList = given().spec(RestAssuredBase.getSpec()).auth().basic(key, secret).baseUri(uri).basePath(path + "/offers/" +INVALID_OFFER_ID).queryParam("programType", "SHOPBACK").queryParam("brandSilo", "WPAC").when().get().then().statusCode(500).extract().path("result.errors.details");
        assertEquals(responseList.get(0), "An unexpected error while processing");
    }
}
