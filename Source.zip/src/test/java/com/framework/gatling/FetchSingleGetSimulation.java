package com.framework.gatling;

import com.framework.common.utilities.APIConfig;
import com.framework.common.utilities.APIUtils;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;

public class FetchSingleGetSimulation extends Simulation {

    private static final Logger log = LoggerFactory.getLogger(FetchSingleGetSimulation.class);
    static String key = null;
    static String secret = null;
    static String path = null;
    static String uri = null;

    static {
        try {
            APIConfig healthConfig = APIUtils.getHealthStatus();
            key = healthConfig.getKey();
            secret = healthConfig.getSecret();
            uri = healthConfig.getUri();
            path = healthConfig.getPath();
        } catch (IOException e) {
            log.error(e.getMessage());
        }
    }

    public FetchSingleGetSimulation() {
        HttpProtocolBuilder httpProtocolBuilder = http.baseUrl(uri)
                .acceptHeader("application/json")
                .contentTypeHeader("application/json");


        ScenarioBuilder healthCheckInfScenario = scenario("ConsumerInf HealthCheck Scenario")
                .exec(http("GET Request").get(path)
                        .basicAuth(key, secret)
                        .check(status().is(200))
                        .check(bodyString().saveAs("responseBody")));

        setUp(
                healthCheckInfScenario.injectOpen(
                        rampUsersPerSec(1).to(100).during(10),
                        constantUsersPerSec(10).during(10)
                ).protocols(httpProtocolBuilder)
        );
    }
}
