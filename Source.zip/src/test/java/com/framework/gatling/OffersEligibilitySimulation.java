package com.framework.gatling;

import com.framework.common.utilities.APIConfig;
import com.framework.common.utilities.APIUtils;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;
import org.json.JSONException;

import java.io.IOException;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;



public class OffersEligibilitySimulation extends Simulation {
    static String key;
    static String secret;
    static String path;
    static String uri;
    static String customerId;
    static String INVALID_CUSTOMER_ID= "12345678";
    static String payload;

    static {
        try {
            APIConfig offerEligibilityConfig = APIUtils.getOfferEligibility();
            payload = offerEligibilityConfig.getPayload().toString();
            customerId = offerEligibilityConfig.getPathVariable().getJSONObject(0).optString("customerId");
            key = offerEligibilityConfig.getKey();
            secret = offerEligibilityConfig.getSecret();
            uri = offerEligibilityConfig.getUri();
            path = offerEligibilityConfig.getPath();
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    public OffersEligibilitySimulation() {
        HttpProtocolBuilder httpProtocol = http.baseUrl(uri)
                .basicAuth(key, secret)
                .acceptHeader("application/json")
                .contentTypeHeader("application/json");

        ScenarioBuilder scn = scenario("Offer Eligibility Scenario")
                .exec(http("Post Offer Eligibility Successfully")
                        .post(path + "/customers/" + customerId + "/offersEligibility")
                        .queryParam("brandSilo", "WPAC")
                        .queryParam("customerIdScheme", "CustomerInternalId")
                        .body(StringBody(payload.toString()))
                        .check(status().is(200))
                        .check(jsonPath("$.data.offerStatus[0].programType").is("SHOPBACK"))
                        .check(jsonPath("$.data.offerStatus[0].isEligible").is(String.valueOf(true)))
                        .check(jsonPath("$.data.offerStatus[1].programType").is("WESTPAC_OFFERS_AND_REWARDS"))
                        .check(jsonPath("$.data.offerStatus[1].isEligible").is(String.valueOf(false)))
                        .check(jsonPath("$.data.offerStatus[1].ineligibilityReason").is("CUSTOMER_ENTITLEMENT_CHECK_FAILED"))
                )
                .pause(5)

                .exec(http("Post Offer Eligibility Missing CustomerIdScheme Param")
                        .post(path + "/customers/" + customerId + "/offersEligibility")
                        .queryParam("brandSilo", "WPAC")
                        .body(StringBody(payload.toString()))
                        .check(status().is(400))
                        .check(jsonPath("$.result.errors.details[0]").is("The required customerIdScheme in query parameter is missing or invalid"))
                )
                .pause(5)

                .exec(http("Post Offer Eligibility Missing BrandSilo Param")
                        .post(path + "/customers/" + customerId + "/offersEligibility")
                        .queryParam("customerIdScheme", "CustomerInternalId")
                        .body(StringBody(payload.toString()))
                        .check(status().is(400))
                        .check(jsonPath("$.result.errors.details[0]").is("The required brandSilo in query parameter is missing or invalid"))
                )
                .pause(5)

                .exec(http("Post Offer Eligibility Having Invalid CustomerId Path Param")
                        .post(path + "/customers/" + INVALID_CUSTOMER_ID + "/offersEligibility")
                        .queryParam("brandSilo", "WPAC")
                        .queryParam("customerIdScheme", "CustomerInternalId")
                        .body(StringBody(payload.toString()))
                        .check(status().is(400))
                        .check(jsonPath("$.result.errors.details[0]").is("The required customerId in path parameter is missing or invalid"))
                );

        setUp(
                scn.injectOpen(
                        rampUsersPerSec(1).to(100).during(10),
                        constantUsersPerSec(10).during(10)
                ).protocols(httpProtocol)
        );
    }
}

