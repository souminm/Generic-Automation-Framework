package com.framework.gatling;


import com.framework.common.utilities.APIConfig;
import com.framework.common.utilities.APIUtils;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;


public class OfferSearchSimulation extends Simulation {
    static String key;
    static String secret;
    static String path;
    static String uri;
    static JSONArray payloadArray;
    static JSONArray pathVariableArray;
    static String firstPayloadItem;
    static String offerId;
    static String INVALID_OFFER_ID = "12345";
    private static final Logger log = LoggerFactory.getLogger(OfferSearchSimulation.class);

    static {
        try {
            APIConfig offerSearchConfig = APIUtils.getOfferSearch();
            payloadArray = offerSearchConfig.getPayload();
            firstPayloadItem = payloadArray.getJSONObject(0).toString();
            pathVariableArray = offerSearchConfig.getPathVariable();
            offerId = pathVariableArray.getJSONObject(0).optString("offerId");
            key = offerSearchConfig.getKey();
            secret = offerSearchConfig.getSecret();
            uri = offerSearchConfig.getUri();
            path = offerSearchConfig.getPath();
        } catch (IOException | JSONException e) {
            throw new RuntimeException(e);
        }
    }

    public OfferSearchSimulation() throws IOException {
        HttpProtocolBuilder httpProtocol = http.baseUrl(uri)
                .basicAuth(key, secret)
                .acceptHeader("application/json")
                .contentTypeHeader("application/json");

        ScenarioBuilder scn = scenario("Offer Search Scenario")
                .exec(http("Post Offer Search Successfully")
                        .post(path + "/offerSearch")
                        .queryParam("brandSilo", "WPAC")
                        .queryParam("programType", "SHOPBACK")
                        .queryParam("Key", "Soumin")
                        .body(StringBody(firstPayloadItem.toString()))
                        .check(status().is(200))
                        .check(jsonPath("$.offers[0].offerId").is("12345"))
                        .check(jsonPath("$.offers[0].name").is("Amazon Australia"))
                        .check(jsonPath("$.offers[0].cashback.displayText").is("Up to 10% Cashback"))
                        .check(jsonPath("$.offers[0].subCategory.name").is("FitnessMock"))
                )
                .pause(5);

        setUp(
                scn.injectOpen(
                        rampUsersPerSec(1).to(100).during(10),
                        constantUsersPerSec(10).during(10)
                ).protocols(httpProtocol)
        );
    }
}


