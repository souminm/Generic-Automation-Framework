package com.framework.common.utilities;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;
import java.util.function.Function;

public class Wait {
    public static final Integer WAIT_TIME = 20;
    private static final Logger log = LoggerFactory.getLogger(Wait.class);

    private static void until(WebDriver webDriver, Duration timeOutInSeconds, Function<WebDriver, Boolean> waitCondition) {
        WebDriverWait webDriverWait = new WebDriverWait(webDriver, timeOutInSeconds);
        try {
            webDriverWait.until(waitCondition);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    public static void untilAjaxCallIsDone(WebDriver webDriver, Integer timeOutInSeconds) {
        until(webDriver, Duration.ofSeconds(timeOutInSeconds), (function) -> {
            Boolean isJqueryCallDone = (Boolean) ((JavascriptExecutor) webDriver).executeScript("return jQuery.active==0");
            if (!isJqueryCallDone) System.out.println("jQuery call is in progress");
            return isJqueryCallDone;
        });
    }

    public static void untilPageReadyState(WebDriver webDriver, Integer timeOutInSeconds) {
        until(webDriver, Duration.ofSeconds(timeOutInSeconds), (function) -> {
            String isPageLoaded = String.valueOf(((JavascriptExecutor) webDriver).executeScript("return document.readyState"));
            if (isPageLoaded.equals("complete")) {
                return true;
            } else {
                log.info("Document is loading");
                return false;
            }
        });
    }

    public static void untilURLContains(WebDriver webDriver, String url, Integer timeOutInSeconds) {
        try {
            new WebDriverWait(webDriver, Duration.ofSeconds(timeOutInSeconds)).until(ExpectedConditions.urlContains(url));
        } catch (NoSuchElementException e) {
            throw new RuntimeException("Web driver does not contains" + url + " Time " + timeOutInSeconds);
        }

    }

    public static void untilElementIsVisible(WebDriver webDriver, WebElement webElement, Integer timeOutInSeconds) {
        try {
            new WebDriverWait(webDriver, Duration.ofSeconds(timeOutInSeconds)).until(ExpectedConditions.visibilityOf(webElement));
        } catch (NoSuchElementException e) {
            throw new RuntimeException("Web element not visible within given time" + webElement + " Time " + timeOutInSeconds);
        }
    }

    public static void untilElementIsInvisible(WebDriver webDriver, WebElement webElement, Integer timeOutInSeconds) {
        try {
            WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(2));
            wait.until(d -> ExpectedConditions.invisibilityOf(webElement));
        } catch (NoSuchElementException e) {
            throw new RuntimeException("Web element still visible within given time" + webElement + " Time " + timeOutInSeconds);
        }
    }

    public static void untilElementIsInvisible(WebDriver webDriver, By by, Integer timeOutInSeconds) {
        try {
            WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(2));
            wait.until(d -> ExpectedConditions.invisibilityOfElementLocated(by));
        } catch (NoSuchElementException e) {
            throw new RuntimeException("Web element located still visible within given time" + by + " Time " + timeOutInSeconds);
        }
    }

    public static void untilElementToBeClickable(WebDriver webDriver, WebElement webElement, Integer timeOutInSeconds) {
        try {
            new WebDriverWait(webDriver, Duration.ofSeconds(timeOutInSeconds)).until(ExpectedConditions.elementToBeClickable(webElement));
        } catch (NoSuchElementException e) {
            throw new RuntimeException("Web element not visible within given time" + webElement + " Time " + timeOutInSeconds);
        }
    }

    public static void untilListElementIsVisible(WebDriver webDriver, List<WebElement> webElements, Integer timeOutInSeconds) {
        new WebDriverWait(webDriver, Duration.ofSeconds(timeOutInSeconds)).until(ExpectedConditions.visibilityOfAllElements(webElements));
    }

    public static void waitTextAppear(WebElement webElement, String text, int timeInSecond) throws InterruptedException {
        int count = 0;
        while (!webElement.getText().equals(text) && count < timeInSecond) {
            Thread.sleep((1000));
            count++;
        }
    }

    public static void waitTextDisappear(WebElement webElement, String text, int timeInSecond) throws InterruptedException {
        int count = 0;
        while (webElement.getText().equals(text) && count < timeInSecond) {
            Thread.sleep((1000));
            count++;
        }
    }

}
