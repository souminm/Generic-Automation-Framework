package com.framework.common.utilities;


import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class APIUtils {

    private static final String API_TEST_ENV_NAME_KEY = "api.test.env";
    private static final String DEFAULT_API_ENVIRONMENT_NAME_VALUE = "sit1";
    private static final String API_COMPONENT_TEMPLATE = "env/%s/data.json";
    private static final Logger log = LoggerFactory.getLogger(APIUtils.class);

    public static String getAPIEnvironmentName() {
        String environmentName = System.getProperty(API_TEST_ENV_NAME_KEY);
        if (environmentName == null) {
            log.info("**API ENV ** HAS SET TO : "+DEFAULT_API_ENVIRONMENT_NAME_VALUE.toUpperCase());
            return DEFAULT_API_ENVIRONMENT_NAME_VALUE;
        }
        log.info("**API ENV ** HAS SET TO : "+environmentName.toUpperCase());
        return environmentName;
    }

    public static APIConfig getOfferSearch() throws IOException {
        try {
            String resourceName = String.format(API_COMPONENT_TEMPLATE, getAPIEnvironmentName());
            String jsonTxt = getResourceContent(resourceName);
            JSONObject offerSearchJson = new JSONObject(jsonTxt).getJSONObject("offerSearch");
            String key = offerSearchJson.getString("key");
            String secret = offerSearchJson.getString("secret");
            String path = offerSearchJson.getString("path");
            String uri = offerSearchJson.getString("uri");
            JSONArray payloadArray = offerSearchJson.getJSONArray("payload");
            JSONArray pathVariableArray = offerSearchJson.getJSONArray("pathVariable");
            return new APIConfig(key, secret, path, uri, payloadArray, pathVariableArray);
        } catch (IOException | JSONException ex) {
            throw new IOException(String.format(
                    "Failed to read offerSearch from data resource [%s].", getAPIEnvironmentName()), ex);
        }
    }

    public static APIConfig getOfferEligibility() throws IOException {
        try {
            String resourceName = String.format(API_COMPONENT_TEMPLATE, getAPIEnvironmentName());
            String jsonTxt = getResourceContent(resourceName);
            JSONObject offerEligibilityJson = new JSONObject(jsonTxt).getJSONObject("offerEligibility");
            String key = offerEligibilityJson.getString("key");
            String secret = offerEligibilityJson.getString("secret");
            String path = offerEligibilityJson.getString("path");
            String uri = offerEligibilityJson.getString("uri");
            JSONArray payloadArray = offerEligibilityJson.getJSONArray("payload");
            JSONArray pathVariableArray = offerEligibilityJson.getJSONArray("pathVariable");
            return new APIConfig(key, secret, path, uri, payloadArray, pathVariableArray);
        } catch (IOException | JSONException ex) {
            throw new IOException(String.format(
                    "Failed to read offerSearch from data resource [%s].", getAPIEnvironmentName()), ex);
        }
    }
    public static APIConfig getHealthStatus() throws IOException {
        try {
            String resourceName = String.format(API_COMPONENT_TEMPLATE, getAPIEnvironmentName());
            String jsonTxt = getResourceContent(resourceName);
            JSONObject offerSearchJson = new JSONObject(jsonTxt).getJSONObject("healthTest");
            String key = offerSearchJson.getString("key");
            String secret = offerSearchJson.getString("secret");
            String path = offerSearchJson.getString("path");
            String uri = offerSearchJson.getString("uri");
            return new APIConfig(key, secret, path, uri,null,null);
        } catch (IOException | JSONException ex) {
            throw new IOException("Failed to read offerSearch from data resource [%s].", ex);
        }
    }

    private static String getResourceContent(String resourceName) throws IOException {
        InputStream is = UIUtils.class.getClassLoader().getResourceAsStream(resourceName);
        if (is == null) {
            throw new IOException(String.format("Invalid resource: %s", resourceName));
        }
        return IOUtils.toString(is, StandardCharsets.UTF_8);
    }
}