package com.framework.common.utilities;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Component
public class UIUtils {


    private static final String URLS_RESOURCE_TEMPLATE = "env/urls.json";

    private static final Logger log = LoggerFactory.getLogger(UIUtils.class);

    public static Object getWebPageProperties(String resourceName, String key) throws IOException {
        try {
            InputStream is = UIUtils.class.getClassLoader().getResourceAsStream(resourceName);
            if (is == null) {
                throw new IOException(String.format("Invalid resource: %s", resourceName));
            }
            String jsonTxt = IOUtils.toString(is, StandardCharsets.UTF_8);
            JSONObject jsonObj = new JSONObject(jsonTxt);
            return jsonObj.get(key);
        } catch (IOException | JSONException ex) {
            throw new IOException(String.format(
                    "Failed to read properties from resource [%s].", resourceName), ex);
        }
    }

    public static String getWebPageUrl() throws IOException {
        String resourceName = String.format(URLS_RESOURCE_TEMPLATE);
        String baseUri = getWebPageProperties(resourceName, "web.base.uri").toString();
        return baseUri;
    }


}
