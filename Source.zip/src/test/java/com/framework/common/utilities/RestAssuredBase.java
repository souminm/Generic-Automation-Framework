package com.framework.common.utilities;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

public class RestAssuredBase {
    public static RequestSpecification getSpec() {
        RequestSpecBuilder reqBuilder = new RequestSpecBuilder();
        reqBuilder.addHeader("Accept", "application/json")
                .addHeader("Content-Type", "application/json")
                .addHeader("x-messageId", "121213c0-4b72-4586-a464-e3244c9d1f81")
                .addHeader("x-appCorrelationId", "ef9f9ad7-5eae-4e93-b377-298acad1565e")
                .addHeader("x-organisationId", "WPAC")
                .addHeader("x-originatingSystemId", "souminm")
                .addHeader("x-consumerType", "Staff");

        reqBuilder.addHeader("x-originatingBSB", "WPAC")
                .addHeader("Cookie", "N-ISD-A008E0-443-CK=2411030538.47873.0000");
        return reqBuilder.build();
    }
}
