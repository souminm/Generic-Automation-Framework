package com.framework.common.utilities;

import org.json.JSONArray;

public class APIConfig {
    private final String key;
    private final String secret;
    private final String path;
    private final String uri;
    private JSONArray payload;
    private JSONArray pathVariable;

    public APIConfig(String key, String secret, String path, String uri, JSONArray payload, JSONArray pathVariable) {
        this.key = key;
        this.secret = secret;
        this.path = path;
        this.uri = uri;
        this.payload = payload;
        this.pathVariable = pathVariable;
    }

    public String getKey() {
        return key;
    }

    public String getSecret() {
        return secret;
    }

    public String getPath() {
        return path;
    }

    public String getUri() {
        return uri;
    }

    public JSONArray getPayload() {
        return payload;
    }

    public JSONArray getPathVariable() {
        return pathVariable;
    }
}