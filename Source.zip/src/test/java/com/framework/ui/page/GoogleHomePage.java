package com.framework.ui.page;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class GoogleHomePage extends PageObject {

    private final Logger log = LoggerFactory.getLogger(GoogleHomePage.class);
    private final WebDriver webDriver;
    @FindBy(name = "q")
    private WebElementFacade searchBox;

    @FindBy(css = "input[name='btnK']") // Google search button
    private WebElementFacade searchButton;

    @FindBy(css = "h3")
    private WebElementFacade searchResults;

    public GoogleHomePage(WebDriver webDriver) {
        this.webDriver = getDriver();

    }

    public void searchFor(String term) {
        waitFor(searchBox).typeAndEnter(term); // This will enter the text and submit
    }

    public void verifySearchResults(String term) {
        waitFor(searchResults).shouldContainText(term);
    }


}
