package com.framework.ui.page;


import com.framework.common.utilities.UIUtils;
import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.io.IOException;


public class GoogleNavigationPage extends PageObject {
    private final WebDriver webDriver;

    public GoogleNavigationPage(WebDriver webDriver) {
        this.webDriver = getDriver();
    }

    public void navigateToHomePage() {
        try {
            webDriver.get(UIUtils.getWebPageUrl());
        } catch (IOException ex) {
            Assert.fail("Fail to get URL from configuration. " + ex.getMessage());
        }
    }

}
