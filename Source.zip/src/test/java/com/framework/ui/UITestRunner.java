package com.framework.ui;

import com.framework.ui.config.Application;
import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.serenitybdd.junit.spring.integration.SpringIntegrationMethodRule;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@RunWith(CucumberWithSerenity.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest
//UI
@CucumberOptions(
        features = "src/test/resources/features/Backlog.feature",
        glue = {"com/framework/ui"}
)

//OPEN CV
//@CucumberOptions(
//        features = "src/test/resources/features/VisualTesting_Opencv.feature",
//        glue = {"com/framework/ui"}
//)
@Configuration
public class UITestRunner {
    @Rule
    public SpringIntegrationMethodRule springIntegrationMethodRule = new SpringIntegrationMethodRule();

    @BeforeClass
    public static void setUp() {
        SpringApplication.run(Application.class);
    }
}
