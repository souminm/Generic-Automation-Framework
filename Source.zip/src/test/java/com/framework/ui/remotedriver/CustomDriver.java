package com.framework.ui.remotedriver;


import groovy.util.logging.Slf4j;
import net.serenitybdd.model.buildinfo.BuildInfo;
import net.thucydides.core.webdriver.DriverSource;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

@Slf4j
public class CustomDriver implements DriverSource {

    public static final String CHROME_VERSION_KEY = "chrome.version";
    public static final String FIREFOX_VERSION_KEY = "firefox.version";
    public static final String EDGE_VERSION_KEY = "edge.version";
    public static final String IE_VERSION_KEY = "ie.version";

    @Override
    public WebDriver newDriver() {

        String browserName = System.getProperty("browser");

        //Setting default value as chrome
        if (browserName == null || browserName.isEmpty()) {
            browserName = "chrome";
        }

        MutableCapabilities cap = new MutableCapabilities();
        cap.setCapability("e34:pacAlias", "westpac-sbox-proxy-pac");

        //Enter your generated token inside e34 in next line.
        cap.setCapability("e34:token", "");
        cap.setCapability("e34:video", "false");
        cap.setCapability("e34:acceptInsecureCerts", "true");
        cap.setCapability("e34:per_test_timeout_ms", 300000);
        cap.setCapability("e34:acceptSslCerts", "true");
        cap.setCapability("e34:handleAlerts", "true");
        if ("chrome".equalsIgnoreCase(browserName)) {
            cap.setCapability(CapabilityType.BROWSER_NAME, "chrome");
            String version = System.getProperty(CHROME_VERSION_KEY);
            if (version != null && !version.isEmpty()) {
                cap.setCapability(CapabilityType.BROWSER_VERSION, version);
                for (Map.Entry<String, Object> entry : cap.asMap().entrySet()) {
                    BuildInfo.section("Chrome properties").setProperty(
                            entry.getKey(), entry.getValue().toString());
                }
            }
        } else if ("edge".equalsIgnoreCase(browserName)) {
            cap.setCapability(CapabilityType.BROWSER_NAME, "MicrosoftEdge");
            String version = System.getProperty(EDGE_VERSION_KEY);
            if (version != null && !version.isEmpty()) {
                cap.setCapability(CapabilityType.BROWSER_VERSION, version);
                for (Map.Entry<String, Object> entry : cap.asMap().entrySet()) {
                    BuildInfo.section("Edge properties").setProperty(
                            entry.getKey(), entry.getValue().toString());
                }
            }
        } else if ("firefox".equalsIgnoreCase(browserName)) {
            cap.setCapability(CapabilityType.BROWSER_NAME, "firefox");
            String version = System.getProperty(FIREFOX_VERSION_KEY);
            if (version != null && !version.isEmpty()) {
                cap.setCapability(CapabilityType.BROWSER_VERSION, version);
                for (Map.Entry<String, Object> entry : cap.asMap().entrySet()) {
                    BuildInfo.section("Firefox properties").setProperty(
                            entry.getKey(), entry.getValue().toString());
                }
            }
        } else if ("ie".equalsIgnoreCase(browserName)) {
            cap.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");
            String version = System.getProperty(IE_VERSION_KEY);
            if (version != null && !version.isEmpty()) {
                cap.setCapability(CapabilityType.BROWSER_VERSION, version);
                for (Map.Entry<String, Object> entry : cap.asMap().entrySet()) {
                    BuildInfo.section("Internet Explorer properties").setProperty(
                            entry.getKey(), entry.getValue().toString());
                }
            }
        } else {
            throw new IllegalArgumentException("Invalid browser specified");
        }

        try {
            return new RemoteWebDriver(
                    new URL("https://seleniumgrid.tst.srv.westpac.com.au/wd/hub"),
                    cap
            );
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean takesScreenshots() {
        return true;
    }
}
