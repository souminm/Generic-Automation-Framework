package com.framework.ui.config;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@org.springframework.test.context.ContextConfiguration(classes = {ContextConfiguration.class})
public class AbstractTestDefinition {
}