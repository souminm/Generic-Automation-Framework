package com.framework.ui.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
public class OpenCVLoader {

    private static final Logger log = LoggerFactory.getLogger(OpenCVLoader.class);

    @PostConstruct
    private void loadOpenCVLibrary() {
        String libraryPath = System.getProperty("user.dir") + "/src/test/resources/opencv/opencv_java460.dll";
        System.out.println("Updated Library Path: " + libraryPath);
        try {
            log.info("Loading OpenCV library...");
            System.load(libraryPath);
            log.info("OpenCV library loaded successfully.");
        } catch (UnsatisfiedLinkError e) {
            log.error(e.getMessage());
        }
    }
}
