package com.framework.ui.step;


import com.framework.ui.config.AbstractTestDefinition;
import com.framework.ui.page.GoogleNavigationPage;
import io.cucumber.java.en.Given;
import org.springframework.stereotype.Service;


@Service
public class GoogleNavigationSteps extends AbstractTestDefinition {
    GoogleNavigationPage googleNavigationPage;

    @Given("the user navigate to webpage")
    public void theUserNavigateToShopbackFrom() {
        googleNavigationPage.navigateToHomePage();
    }
}
