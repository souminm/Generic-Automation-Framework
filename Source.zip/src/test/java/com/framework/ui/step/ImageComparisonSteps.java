package com.framework.ui.step;

import com.framework.opencv.ImageVerification;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ImageComparisonSteps {

    private String imagePath1;
    private String imagePath2;
    private boolean imagesMatch;

    @Given("the user has two images with paths {string} and {string}")
    public void theUserHasTwoImagesWithPaths(String path1, String path2) {
        imagePath1 = path1;
        imagePath2 = path2;
    }

    @When("the user compares the two images")
    public void theUserComparesTheTwoImages() throws Exception {
        imagesMatch = ImageVerification.compareImages(imagePath1, imagePath2);
    }

    @Then("the images should match")
    public void theImagesShouldMatch() {
        assertTrue("Images do not match", imagesMatch);
    }

    @Then("the images should not match")
    public void theImagesShouldNotMatch() {
        assertFalse("Images do not match", imagesMatch);
    }
}
