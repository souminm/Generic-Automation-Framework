package com.framework.ui.step;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;

public class MatrixSteps {

    private Mat matrix;

    @Given("a 3x3 matrix with all elements set to 1.0")
    public void createMatrix() {
        matrix = Mat.ones(3, 3, CvType.CV_64F);
    }

    @When("the matrix is converted to CV_64F data type")
    public void convertMatrix() {
        matrix.convertTo(matrix, CvType.CV_64F);
    }

    @When("the matrix is multiplied by a scalar value of {int}")
    public void multiplyMatrix(int scalarValue) {
        Core.multiply(matrix, new Scalar(scalarValue), matrix);
    }

    @Then("the resulting matrix should be displayed")
    public void displayResultingMatrix() {
        System.out.println("Resulting Matrix:\n" + matrix.dump());
    }
}

