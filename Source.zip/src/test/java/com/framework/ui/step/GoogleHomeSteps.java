package com.framework.ui.step;

import com.framework.ui.config.AbstractTestDefinition;
import com.framework.ui.page.GoogleHomePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.stereotype.Service;

@Service
public class GoogleHomeSteps extends AbstractTestDefinition {
    GoogleHomePage googleHomePage;

    @When("user search for {string}")
    public void searchForTerm(String term) {
        googleHomePage.searchFor(term);
    }

    @Then("user should see search results related to {string}")
    public void verifySearchResults(String term) {
        googleHomePage.verifySearchResults(term);
    }
}